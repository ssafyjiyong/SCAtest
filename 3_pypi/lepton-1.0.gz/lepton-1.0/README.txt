Lepton
======

https://bitbucket.org/lordmauve/lepton/

Lepton: A high-performance, pluggable particle engine and API for Python

Requirements
------------

Lepton is platform-independent and should run on any operating system
supporting Python and OpenGL. Let us know if you try to build
and run Lepton on an unusual platform.

The following are required to build and install Lepton:

* Python 2.6+, 3.3+
* OpenGL
* A C compiler (GCC or Visual C++)

To build on Linux (and possibly other unix-like OSes) You will need to have
the Python and libxext headers installed. On systems using the apt packaging
system, this means you need to have the python-dev-all and libxext-dev
packages installed. Specifically on Debian and Ubuntu, you will likely
need the following packages installed:

xorg-dev
libgl1-mesa-dev
libglu1-mesa-dev

Binary releases for Windows are available for download from the google code
site above.  If you'd like to help out by contributing a binary distribution
for your platform, you're more than welcome to!

The examples provided with Lepton require either pyglet
(http://www.pyglet.org), or pygame (http://www.pygame.org),
but neither are required to use the library.

Alpha Software
--------------

Lepton is currently under development, and the APIs may change in future
versions. That said, it has many useful features already and the developers
will attempt to minimize breakage where possible or provide migration
documentation for new versions.

If you find a bug, or desire a feature, please use the issue tracker at:

https://bitbucket.org/lordmauve/lepton/issues?status=new&status=open


Installation
------------

If you're reading this README from a source distribution, install lepton
with::

    python setup.py install

If you just want to test it out without installing it, you can use::

    python setup.py build_ext --inplace

Then add this directory to your PYTHONPATH.

Support
-------

If you find a bug, use the issue tracker above. If you'd like to discuss
usage, new features or contribute to Lepton, join our google group at:

http://groups.google.com/group/py-lepton-users

Credits
-------

Casey Duncan -- Lepton creator and primary developer
Jussi Lepistö -- Windows maintainer
Andrew Charles -- Code contributor
Harry Tormey -- Inspiration and code contributor

And thanks to others for their contributions of ideas and bugfixes!
