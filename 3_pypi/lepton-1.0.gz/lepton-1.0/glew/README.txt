This directory contains excerpts from the GLEW project
containing licence-compatible pieces of GLEW needed by
Lepton.

For more information see the GLEW website:

http://glew.sourceforge.net/
