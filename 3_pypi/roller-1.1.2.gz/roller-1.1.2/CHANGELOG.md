# 1.0.0 / 2015-01-19

* [ENHANCEMENT] Stabilized API

