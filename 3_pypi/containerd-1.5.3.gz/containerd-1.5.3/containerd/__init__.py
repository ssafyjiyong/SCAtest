# library/package semantic version
__api_version__ = '1.5'
__generation__ = 3
