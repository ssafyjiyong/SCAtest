jquery

This is a TurboGears (http://www.turbogears.org) widget project.
You can view the widgets in the Toolbox.