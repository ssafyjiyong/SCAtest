# coding: utf-8
from __future__ import absolute_import, division, print_function

from logbook import Logger

logger = Logger('yourls')
logger.disabled = True
