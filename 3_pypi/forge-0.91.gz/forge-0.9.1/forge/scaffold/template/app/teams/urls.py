app_name = "teams"

urlpatterns = []
