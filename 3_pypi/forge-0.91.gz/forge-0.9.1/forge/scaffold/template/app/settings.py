from forge.default_settings import *

INSTALLED_APPS = INSTALLED_APPS + [
    "teams",
    "users",
]

TIME_ZONE = "America/Chicago"
