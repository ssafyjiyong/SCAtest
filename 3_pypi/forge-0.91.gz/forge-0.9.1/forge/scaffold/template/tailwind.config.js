module.exports = {
  theme: {
    extend: {
      // Add custom colors etc here
    },
  },
  plugins: [
    require("@tailwindcss/forms"),
  ],
}
