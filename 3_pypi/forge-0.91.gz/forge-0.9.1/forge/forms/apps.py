from django.apps import AppConfig


class ForgeFormsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "forge.forms"
    label = "forge_forms"
