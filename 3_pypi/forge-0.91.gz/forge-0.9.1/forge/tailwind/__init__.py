from .core import Tailwind

__all__ = ["Tailwind"]
