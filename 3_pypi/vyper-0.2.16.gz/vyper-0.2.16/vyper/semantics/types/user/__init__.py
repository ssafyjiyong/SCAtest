from . import event, interface, struct

USER_TYPES = {"event": event, "interface": interface, "struct": struct}
