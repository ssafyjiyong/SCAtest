Welcome to the LIEF's Doxygen Documentation

<img src="https://data.romainthomas.fr/LIEF/lief_front_940x752.png" alt="LIEF Architecture" width="500" />

To get started, you can look at the LIEF::ELF namespace or the LIEF::PE::Binary class.

If you find a typo or you want to improve the documentation, feel free to open an issue or a pull request.

Enjoy!
