MachO
-----

.. doxygenfunction:: macho_parse
   :project: lief


.. doxygenfunction:: macho_binaries_destroy
   :project: lief


Macho_Binary_t
**************

.. doxygenstruct:: Macho_Binary_t
   :project: lief


----------

Macho_Header_t
**************

.. doxygenstruct:: Macho_Header_t
   :project: lief

----------

Macho_Section_t
***************

.. doxygenstruct:: Macho_Section_t
   :project: lief

----------

Macho_Segment_t
***************

.. doxygenstruct:: Macho_Segment_t
   :project: lief


----------

Macho_Command_t
***************

.. doxygenstruct:: Macho_Command_t
   :project: lief


----------

Macho_Symbol_t
**************

.. doxygenstruct:: Macho_Symbol_t
   :project: lief

