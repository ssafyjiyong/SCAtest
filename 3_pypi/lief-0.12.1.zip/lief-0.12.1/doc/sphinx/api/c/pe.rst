PE
--


.. doxygenfunction:: pe_parse
   :project: lief


.. doxygenfunction:: pe_binary_destroy
   :project: lief

Pe_Binary_t
************

.. doxygenstruct:: Pe_Binary_t
   :project: lief


----------

Pe_DosHeader_t
**************

.. doxygenstruct:: Pe_DosHeader_t
   :project: lief

----------

Pe_Header_t
***********

.. doxygenstruct:: Pe_Header_t
   :project: lief

----------

Pe_OptionalHeader_t
*******************

.. doxygenstruct:: Pe_OptionalHeader_t
   :project: lief


----------

Pe_Section_t
************

.. doxygenstruct:: Pe_Section_t
   :project: lief


----------

Pe_DataDirectory_t
******************

.. doxygenstruct:: Pe_DataDirectory_t
   :project: lief


----------

Pe_Import_t
***********

.. doxygenstruct:: Pe_Import_t
   :project: lief


----------

Pe_ImportEntry_t
****************

.. doxygenstruct:: Pe_ImportEntry_t
   :project: lief

