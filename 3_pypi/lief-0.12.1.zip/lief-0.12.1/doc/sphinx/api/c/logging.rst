Logging
=======

.. doxygenfunction:: lief_logging_disable
   :project: lief

.. doxygenfunction:: lief_logging_enable
   :project: lief

.. doxygenfunction:: lief_logging_set_level
   :project: lief

