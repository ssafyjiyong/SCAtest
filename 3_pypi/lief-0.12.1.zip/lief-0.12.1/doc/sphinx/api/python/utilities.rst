Utilities
---------

.. autofunction:: lief.is_pe

.. autofunction:: lief.is_elf

.. autofunction:: lief.is_macho

.. autofunction:: lief.is_oat

.. autofunction:: lief.oat_version

.. autofunction:: lief.is_dex

.. autofunction:: lief.dex_version

.. autofunction:: lief.is_vdex

.. autofunction:: lief.vdex_version

.. autofunction:: lief.is_art

.. autofunction:: lief.art_version

.. autofunction:: lief.shell

.. autofunction:: lief.breakp

.. autofunction:: lief.demangle
