Android
=======


Utilities
*********

.. autofunction:: lief.Android.code_name

.. autofunction:: lief.Android.version_string

-----------


Android Versions
*****************

.. autoclass:: lief.Android.ANDROID_VERSIONS
  :members:
  :inherited-members:
  :undoc-members:
