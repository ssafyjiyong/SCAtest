Android
=======


Utilities
*********

.. doxygenfunction:: LIEF::Android::code_name
   :project: lief

.. doxygenfunction:: LIEF::Android::version_string
   :project: lief

-----------

Android Versions
*****************

.. doxygenenum:: LIEF::Android::ANDROID_VERSIONS
   :project: lief
