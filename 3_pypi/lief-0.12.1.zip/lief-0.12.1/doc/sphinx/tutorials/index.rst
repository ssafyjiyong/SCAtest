Tutorials
=========

.. toctree::
  :maxdepth: 2

  01_play_with_formats.rst
  02_pe_from_scratch.rst
  03_elf_change_symbols.rst
  04_elf_hooking.rst
  05_elf_infect_plt_got.rst
  06_pe_hooking.rst
  07_pe_resource.rst



